<?php
include("contents_of_page.php");


echo '
    <header>

        ASIA FUSION

    </header>';

include("login_form.php");

echo '
    <div class="page">
        <div class="text-container">
            <p> '.$about.' </p>
        </div> 
        <div class="sushi">
            <img src="./images/jelo3.jpg" alt="sushi">
        </div> 
        <h1> RESERVE YOUR TABLE NOW</h1> 
        <div class="form-container">
            <form method="POST" action="contents_of_page.php">

                <div class="input-group">
                    <label for="name">Name:</label>
                    <input type="text" name="name_of" value=" " />
                </div>
            
                <div class="input-group">
                    <label for="surname">Surname:</label>
                    <input type="text" name="surname" value="" />
                </div>
            
                <div class="input-group">
                    <label for="numppl">Number of people:</label>
                    <input type="number" name="number_of_people" value="" max="10" min ="1"/>
                </div>
            
                <div class="input-group">
                    <label for="date">Date:</label>
                    <input type="date" name="date_of" value=""/>
                </div>
                
                <div class="input-group">
                    <label for="time">Time:</label>
                    <input type="time" name="time_of" value="" />
                </div>
            
                <div class="input-group">
                    <label for="email">Email:</label>
                    <input type="text" name="email" value="" />
                </div>
            
                <div class="input-group">
                    <label for="specreq">Special requirements:</label>
                    <input type="text" name="add_on_text" value="" />
                </div>
            
                <button type="submit" name="btn_save">RESERVE</button>
        
        </form>
    </div>
    <footer>
        <div class="footer-container">
            <div class="footer-section">
                <h3>Address</h3>
                <p>' . $adres . '</p>
            </div>
            <div class="footer-section">
                <h3>Contact</h3>
                <p>' . $contact . '</p>
            </div>
            <div class="footer-section">
                <h3>Email</h3>
                <p>' . $email_owner . '</p>
            </div>
        </div>
    </footer>
   
</div>';


?>