<?php


include("db_connection.php");

if (isset($_POST["btn_edit"])) {
    $names        = mysqli_real_escape_string($con, $_POST["name_of"]);
    $surname       = mysqli_real_escape_string($con, $_POST["surname"]);
    $number     = mysqli_real_escape_string($con, $_POST["number_of_people"]);
    $date    = mysqli_real_escape_string($con, $_POST["date_of"]); // dal mi treba ovo za date i time s obzirom da ne dolaze u string obliku - da zato sto html forma importa u php to kao type string
    $time = mysqli_real_escape_string($con, $_POST["time_of"]);
    $email        = mysqli_real_escape_string($con, $_POST["email"]);
    $specr        = mysqli_real_escape_string($con, $_POST["add_on_text"]);

    $id = (int)$_GET["id"];

    $query_upd = "UPDATE rezervations SET
                    name_of='$names',
                    surname='$surname',
                    number_of_people='$number',
                    date_of='$date',
                    time_of='$time',
                    email='$email',
                    add_on_text='$specr'
                    WHERE id='$id'";

    $result_upd = mysqli_query($con, $query_upd);

    if ($result_upd) {
        header("Location: administracija.php");
        exit;
    } else {
        echo 'There was an error please try again ';
    }
}
if (isset($_POST["btn_save"])) {
    $names        = mysqli_real_escape_string($con, $_POST["name_of"]);
    $surname       = mysqli_real_escape_string($con, $_POST["surname"]);
    $number     = mysqli_real_escape_string($con, $_POST["number_of_people"]);
    $date    = mysqli_real_escape_string($con, $_POST["date_of"]); // dal mi treba ovo za date i time s obzirom da ne dolaze u string obliku - da zato sto html forma importa u php to kao type string
    $time = mysqli_real_escape_string($con, $_POST["time_of"]);
    $email        = mysqli_real_escape_string($con, $_POST["email"]);
    $specr        = mysqli_real_escape_string($con, $_POST["add_on_text"]);

    $query_ins = "INSERT INTO rezervations
                    (name_of, surname, number_of_people, date_of, time_of, email,add_on_text)
                    VALUES
                    ('$names', '$surname', '$number', '$date', '$time', '$email','$specr')";

    $result_ins = mysqli_query($con, $query_ins);

    if ($result_ins) {
        header("Location: administracija.php");
        exit;
    } else {
        echo 'There was an error , try again';
    }
}


if (isset($_GET["id"])) {
    $id = (int)$_GET["id"];

    $id = mysqli_real_escape_string($con, $id);

    $query = "SELECT * FROM rezervations WHERE id = '$id'";
    $result = mysqli_query($con, $query);

    $student = mysqli_fetch_assoc($result);

    $names        = $student["name_of"];
    $surname       = $student["surname"];
    $number     = $student["number_of_people"];
    $date    = $student["date_of"];
    $time = $student["time_of"];
    $email        = $student["email"];
    $specr        = $student["add_on_text"];

    $btn = "btn_edit";
    echo 'You are now edditing existing reservation';
} else {
    $names        = "";
    $surname       = "";
    $number     = "";
    $date    = "";
    $time = "";
    $email        = "";
    $specr        = "";

    $btn = "btn_save";
}

include("form_reservation.php");
?>
