<?php


$db_server   = "localhost";
$db_user     = "root";
$db_password = "";
$database    = "project_asia";

$con = mysqli_connect($db_server, $db_user, $db_password, $database);

if(mysqli_connect_errno() > 0)
{
    echo 'you are not connected to database';
    echo mysqli_connect_error();
    exit;
}
else
{
    mysqli_query($con, "SET NAMES utf8");
}

?>