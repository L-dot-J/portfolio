<?php

echo '
<div class="login-bar">
    <form method="POST" action="" class="login-form">
        <input type="text" id="username" name="username" value="" placeholder="Username" />
        <input type="password" id="password" name="password" value="" placeholder="Password" />
        <button type="submit" name="btn_login">Login</button>
    </form>
</div>';

?>