-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2024 at 11:59 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_asia`
--

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `about` longtext DEFAULT NULL,
  `contact` int(20) DEFAULT NULL,
  `email_of_owner` varchar(100) DEFAULT NULL,
  `adress` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`about`, `contact`, `email_of_owner`, `adress`) VALUES
('Welcome to ASIA FUSION, where passion meets tradition in every dish.\r\n            Our journey began with a shared love for the rich and diverse\r\n            flavors of Asian cuisine. Inspired by the bustling street markets\r\n            and family kitchens of Asia, we embarked on a culinary adventure to\r\n            bring you an authentic taste of the East. Our chefs, steeped in\r\n            tradition, handcraft each dish with care, using only the finest\r\n            ingredients to capture the essence of Asian gastronomy. From the\r\n            sizzling woks to the aromatic spices, every bite at Asia Fusion is a journey through the vibrant landscapes of Asia. Whether\r\n            you re a connoisseur of classic favorites or eager to explore bold,\r\n            innovative creations, our menu is a celebration of flavors that\r\n            transcends borders.      Asian cuisine is a symphony of tantalizing tastes that dance on the\r\n            palate, creating a sensory experience like no other. Bursting with\r\n            bold and harmonious flavors, its a celebration of contrasts—sweet\r\n            and savory, spicy and mild, tangy and umami. From the delicate\r\n            subtlety of sushi to the fiery kick of Thai curries, Asian dishes\r\n            are a masterpiece of balance, often guided by the ancient principles\r\n            of yin and yang. The secret lies in the artful blend of fresh herbs,\r\n            aromatic spices, and umami-rich ingredients that elevate each bite\r\n            to an unforgettable journey. Whether its the comforting warmth of\r\n            miso soup, the crisp perfection of tempura, or the complex layers of\r\n            a steaming bowl of pho, Asian cuisine is a testament to the belief\r\n            that every mouthful should be a discovery.', +385991234321, 'asia-fusion@gmail.com', 'Ulica Vatroslava Lisinskog 14, Zagreb');

-- --------------------------------------------------------

--
-- Table structure for table `rezervations`
--

CREATE TABLE `rezervations` (
  `id` int(11) NOT NULL,
  `name_of` varchar(50) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `number_of_people` int(2) NOT NULL,
  `date_of` date NOT NULL,
  `time_of` time NOT NULL,
  `email` varchar(100) NOT NULL,
  `add_on_text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rezervations`
--
ALTER TABLE `rezervations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rezervations`
--
ALTER TABLE `rezervations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
