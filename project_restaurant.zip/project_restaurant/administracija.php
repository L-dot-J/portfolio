<?php

echo '
<!DOCTYPE HTML>
<html>
    <head>
        <title>ASIA FUSION</title>
        <link rel="stylesheet" type="text/css" href="./styles/main.css">
    </head>
<body>
    <a href="logout.php" class="button-link" id="logout">Log out</a>
    <h1 class = "admin_h1">WELCOME TO ADMIN PAGE</h1>   
    <div class="page">';

include("content_change.php");
echo '
        <div class ="formtop">
            <div class="row">
                <div class="form-container">
                    <h2>Content changes</h2>
                    <form method="POST" action="">

                        <div class="input-group">
                            <label >About:</label>
                            <input type="text" name="about" value="" />
                        </div>

                        <div class="input-group">
                            <label >Contact:</label>
                            <input type="text" name="contact" value="" />
                        </div>
                    
                        <div class="input-group">
                            <label >Email:</label>
                            <input type="text" name="email_content" value="" />
                        </div>

                        <div class="input-group">
                            <label >Adress:</label>
                            <input type="text" name="adress_content" value=""/>
                        </div>
                        
                        <button type="submit" name="btn_save_content" onclick="return confirm(\'Are you sure?\')">SAVE</button>

                    </form>
                </div>';

include("save_and_edit.php");
echo        '</div>';

$query = "SELECT *
            FROM rezervations
            ORDER BY date_of ASC, time_of ASC";

$result = mysqli_query($con, $query);

echo '
            <div class="form-container" id="special">
                <form method="POST" action="">
                        
                    <div class="input-group">
                        <label for="name">Search the table:</label>
                        <input type="text" name="search-surname" value="" placeholder="search by surname" />
                    </div>

                    <div class="input-group">
                        <input type="date" name="date_res" value=""  />
                    </div>

                    <button type="submit" name="btn_search">Search</button>
                </form>
            </div>
        </div>
        <div>
        </br> 
        <a href = "administracija.php" class="button-link">Clear search</a>
        </div>


        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>SURNAME</th>            
                    <th>NUMBER OF PEOPLE</th>
                    <th>DATE</th>            
                    <th>TIME</th>            
                    <th>EMAIL</th>            
                    <th>SPECIAL REQUIREMENTS</th>   
                    <th>EDIT</th>           
                </tr>
            </thead>
            <tbody>';

$rbr = 1;

while ($row = mysqli_fetch_assoc($result)) {
    $id         = $row["id"];
    $name       = $row["name_of"];
    $surname    = $row["surname"];
    $number     = $row["number_of_people"];
    $dates      = $row["date_of"];
    $times      = $row["time_of"];
    $email      = $row["email"];
    $req        = $row["add_on_text"];

    if (isset($_POST["btn_search"])) {
        $search = strtoupper($_POST["search-surname"]);
        $date_search = strtoupper($_POST["date_res"]);

        if ($search != strtoupper(substr($surname, 0, strlen($search))) || $date_search != strtoupper(substr($dates, 0, strlen($date_search)))) {
            continue;
        }
    }


echo '
            <tr>
                <td>' . $id . '.</td>
                <td>' . $name . '</td>
                <td>' . $surname . '</td>
                <td>' . $number . '</td>
                <td>' . $dates . '</td>
                <td>' . $times . '</td>
                <td>' . $email . '</td>
                <td>' . $req . '</td>
                <td>
                <a href="administracija.php?id=' . $id . '">Edit reservation</a>
                |
                <a href="delete_form.php?id=' . $id . '" onclick="return confirm(\'Are you sure?\')">Delete</a>
            </td> 
            </tr>';

    $rbr++;
}

echo '
            </tbody>
        </table>
    </div>
</body>';
