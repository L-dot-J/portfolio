<?php
include('db_connection.php');

if (isset($_POST['btn_save_content'])) {
    $about        = mysqli_real_escape_string($con, $_POST['about']);
    $contact_owner       = mysqli_real_escape_string($con, $_POST['contact']);
    $adress     = mysqli_real_escape_string($con, $_POST['adress_content']);
    $email_owner    = mysqli_real_escape_string($con, $_POST['email_content']);

    $new_content = array($about, $contact_owner, $adress, $email_owner);
    $names = array('about', 'contact', 'adress', 'email_of_owner');

    $query_upd = 'UPDATE content SET ';

    for ($i = 0; $i < count($new_content); $i++) {
   
        if ($new_content[$i]) {
            $query_upd .= $names[$i] . " = '" . mysqli_real_escape_string($con, $new_content[$i]) . "',";
        }
        
    }

    $query_upd = rtrim($query_upd, ',');
    

    $result_upd = mysqli_query($con, $query_upd);

    if ($result_upd) {
        header('Location:administracija.php');
        exit;
    } else {
        echo 'There was an error please try again ';
    }
}
