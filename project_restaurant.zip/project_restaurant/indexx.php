<?php




include("db_connection.php");

session_start();

$login = false;

if (isset($_POST["btn_login"])) {
    $username = mysqli_real_escape_string($con, $_POST["username"]);
    $password = mysqli_real_escape_string($con, $_POST["password"]);

    $query = "SELECT *
                FROM user
                WHERE username LIKE '$username'
                AND password = MD5('$password')"; // tu hasham ono sto mi je korisnik dao 

    $result = mysqli_query($con, $query);

    $br_rows = mysqli_num_rows($result);

    if ($br_rows <= 0) {
        $_SESSION["login"] = false;
        echo '<p>Wrong password or username. Try again.</p>';
    } else {
        $user = mysqli_fetch_assoc($result);

        $_SESSION["login"] = true;
        $_SESSION["id"] = $user["id"];
    }
}

echo '<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ASIA FUSION </title>
        <link rel="stylesheet" type="text/css" href="./styles/main.css">
    </head>
    <body>';

if (isset($_SESSION["login"]) && $_SESSION["login"] === true) {
    include("administracija.php");
} else {
    include("start.php");
}


echo '
    </body>
</html>';
?>