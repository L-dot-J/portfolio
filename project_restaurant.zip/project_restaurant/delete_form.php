<?php


include("db_connection.php");

if(isset($_GET["id"]))
{
    $id = (int)$_GET["id"];

    $id = mysqli_real_escape_string($con, $id);

    if($id > 0)
    {
        $query_del = "DELETE FROM rezervations WHERE id='$id' LIMIT 1";

        $result_del = mysqli_query($con, $query_del);

        if($result_del)
        {
            header("Location: administracija.php");
            exit;
        }
        else
        {
            echo 'There was an error in delete, please try again';
        }        
    }
}

?>