<?php

echo '
<div class="form-container">
    <h2>Make a reservation</h2>
    <form method="POST" action="">

        <div class="input-group">
            <label for="name_of">Name:</label>
            <input type="text" name="name_of" value="' . $names . '" />
        </div>

        <div class="input-group">
            <label for="surname">Surname:</label>
            <input type="text" name="surname" value="' . $surname . '" />
        </div>

        <div class="input-group">
            <label for="number_of_people">Number of people:</label>
            <input type="number" name="number_of_people" value="' . $number . '" max="10" min ="1"/>
        </div>

        <div class="input-group">
            <label for="date_of">Date:</label>
            <input type="date" name="date_of" value="' . $date . '"/>
        </div>

        <div class="input-group">
            <label for="time_of">Time:</label>
            <input type="time" name="time_of" value="' . $time . '" />
        </div>

        <div class="input-group">
            <label for="email">Email:</label>
            <input type="text" name="email" value="' . $email . '" />
        </div>

        <div class="input-group">
            <label for="add_on_text">Special requirements:</label>
            <input type="text" name="add_on_text" value="' . $specr . '" />
        </div>

        <button type="submit" name="' . $btn . '">SAVE</button>

    </form>
</div>';