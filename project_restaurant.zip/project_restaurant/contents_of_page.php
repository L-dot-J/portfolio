<?php

include("db_connection.php");

$query = "SELECT *
            FROM content";

$resultt = mysqli_query($con, $query);

while ($row = mysqli_fetch_assoc($resultt)) {
    $about         = $row["about"];
    $contact       = $row["contact"];
    $email_owner    = $row["email_of_owner"];
    $adres    = $row["adress"];
}
if (isset($_POST["btn_save"])) {
    $names        = mysqli_real_escape_string($con, $_POST["name_of"]);
    $surname       = mysqli_real_escape_string($con, $_POST["surname"]);
    $number     = mysqli_real_escape_string($con, $_POST["number_of_people"]);
    $date    = mysqli_real_escape_string($con, $_POST["date_of"]);
    $time = mysqli_real_escape_string($con, $_POST["time_of"]);
    $email        = mysqli_real_escape_string($con, $_POST["email"]);
    $specr        = mysqli_real_escape_string($con, $_POST["add_on_text"]);

    $query_ins = "INSERT INTO rezervations
                    (name_of, surname, number_of_people, date_of, time_of, email,add_on_text)
                    VALUES
                    ('$names', '$surname', '$number', '$date', '$time', '$email','$specr')";

    $result_ins = mysqli_query($con, $query_ins);

    if ($result_ins) {
        header("Location:indexx.php");
        exit;
    } else {
        echo 'There was an error , try again';
    }
}
?>
